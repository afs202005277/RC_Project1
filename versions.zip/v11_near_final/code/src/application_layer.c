// Application layer protocol implementation

#include <stdio.h>
#include "application_layer.h"
#include "link_layer.h"
#include "tmp.h"
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

unsigned char *getStartPacket(int filesize, const char *filename, unsigned int *size)
{
    unsigned int sz_1 = sizeof(filesize);
    unsigned int sz_2 = strlen(filename);
    *size = sz_1 + sz_2 + 5;
    unsigned char *packet = malloc(*size);
    packet[0] = 2;
    packet[1] = 0;
    packet[2] = sz_1;
    memcpy(&packet[3], &filesize, sz_1);
    packet[3 + sz_1] = 1;
    packet[4 + sz_1] = sz_2;
    memcpy(&packet[5 + sz_1], filename, sz_2);
    return packet;
}

int getFileSize(const char *filename)
{
    struct stat st;
    stat(filename, &st);
    return st.st_size;
}

void applicationLayer(const char *serialPort, const char *role, int baudRate,
                      int nTries, int timeout, const char *filename)
{
    LinkLayer connectionParameters;
    connectionParameters.baudRate = baudRate;
    connectionParameters.nRetransmissions = nTries;
    if (strcmp("tx", role) == 0)
    {
        connectionParameters.role = LlTx;
    }
    else if (strcmp("rx", role) == 0)
    {
        connectionParameters.role = LlRx;
    }
    else
    {
        printf("Invalid role!\n");
        exit(-1);
    }

    connectionParameters.timeout = timeout;
    strcpy(connectionParameters.serialPort, serialPort);

    unsigned int sizeControlPacket = 0;
    unsigned char *startPacket = getStartPacket(getFileSize(filename), filename, &sizeControlPacket);

    if (connectionParameters.role == LlTx)
    {
        unsigned char *endPacket = malloc(sizeControlPacket);
        memcpy(endPacket, startPacket, sizeControlPacket);
        endPacket[0] = 3;

        if (llopen(connectionParameters) == -1)
        {
            printf("Couldn't open logical connection!\n");
            exit(-1);
        }
        sendInformationFrame(startPacket, sizeControlPacket);

        int file = open(filename, O_RDONLY);
        unsigned char buffer[MAX_PAYLOAD_SIZE];
        unsigned int read_bytes = 0, sequence_number = 0;
        while ((read_bytes = read(file, buffer + 4, MAX_PAYLOAD_SIZE - 4)) > 0)
        {
            buffer[0] = 1;
            buffer[1] = sequence_number % 256;
            buffer[2] = read_bytes / 256;
            buffer[3] = read_bytes % 256;
            if (sendInformationFrame(buffer, read_bytes+4) == -1)
            {
                printf("Timeout\n");
                break;
            }
            sequence_number++;
        }
        close(file);

        sendInformationFrame(endPacket, sizeControlPacket);

        llclose(0);
    }
    else
    {
        unsigned char receivedStart = FALSE;
        llopen(connectionParameters);
        int file = open(filename, O_RDWR | O_CREAT, S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
        unsigned char *packet = malloc(MAX_PAYLOAD_SIZE);
        unsigned char *received_packet = malloc(sizeControlPacket);
        unsigned int received_bytes = 0, expecting_sequence_number = 0;
        while ((received_bytes = getInformationFrame(packet)) != 0)
        {
            if (received_bytes != -1)
            {
                if (packet[0] == 1)
                {
                    if (expecting_sequence_number % 256 == packet[1] && 256 * packet[2] + packet[3] == received_bytes-4)
                    {
                        write(file, packet + 4, received_bytes-4);
                    }
                    expecting_sequence_number++;
                }
                else if (packet[0] == 2)
                {
                    if (!receivedStart) {
                        receivedStart = TRUE;
                        memcpy(received_packet, packet, sizeControlPacket);
                    }
                }
                else if (packet[0] == 3)
                {
                    received_packet[0] = 3;
                    if (!receivedStart)
                    {
                        printf("Received END packet without receiving the START packet\n");
                        exit(-1);
                    }
                    else if (memcmp(packet, received_packet, received_bytes) != 0)
                    {
                        printf("End packets do not match!\n");
                        exit(-1);
                    }
                }
            }
        }
        close(file);
    }
}